-- Add default forum categories
INSERT INTO forum_categories (name, description, icon, order_index) VALUES
    ('General Discussion', 'General gaming discussions and topics', 'fa-comments', 1),
    ('Game Help', 'Get help with specific games', 'fa-question-circle', 2),
    ('News & Updates', 'Latest gaming news and updates', 'fa-newspaper', 3),
    ('Technical Support', 'Technical issues and troubleshooting', 'fa-wrench', 4),
    ('Community Events', 'Community events and tournaments', 'fa-calendar', 5)
ON CONFLICT (name) DO NOTHING; 