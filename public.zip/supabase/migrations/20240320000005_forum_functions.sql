-- First drop the trigger that depends on handle_new_user
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

-- Now drop existing functions
DROP FUNCTION IF EXISTS get_thread_list;
DROP FUNCTION IF EXISTS get_comment_tree;
DROP FUNCTION IF EXISTS is_username_available;
DROP FUNCTION IF EXISTS handle_new_user;
DROP FUNCTION IF EXISTS get_user_role;

-- Create is_username_available function
CREATE OR REPLACE FUNCTION is_username_available(username TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN NOT EXISTS (
        SELECT 1 FROM profiles WHERE profiles.username = username
    );
END;
$$;

-- Create get_thread_list function
CREATE OR REPLACE FUNCTION get_thread_list(
    page_size INTEGER,
    page_number INTEGER,
    filter_category_id UUID DEFAULT NULL,
    search_term TEXT DEFAULT NULL
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    total_count INTEGER;
    offset_value INTEGER;
    threads JSON;
    total_pages INTEGER;
BEGIN
    -- Calculate offset
    offset_value := (page_number - 1) * page_size;
    
    -- Get total count
    SELECT COUNT(*)
    INTO total_count
    FROM forum_posts
    WHERE (filter_category_id IS NULL OR category_id = filter_category_id)
    AND (search_term IS NULL OR 
         title ILIKE '%' || search_term || '%' OR 
         content ILIKE '%' || search_term || '%');
    
    -- Calculate total pages
    total_pages := CEIL(total_count::float / page_size);
    
    -- Get threads
    SELECT COALESCE(
        json_agg(
            json_build_object(
                'id', p.id,
                'title', p.title,
                'content', p.content,
                'created_at', p.created_at,
                'updated_at', p.updated_at,
                'author_username', pr.username,
                'category_id', p.category_id,
                'category_name', c.name,
                'comment_count', COALESCE(comment_counts.count, 0),
                'is_pinned', p.is_pinned,
                'is_locked', p.is_locked,
                'tags', COALESCE(tag_array.tags, '[]'::json)
            )
            ORDER BY 
                p.is_pinned DESC,
                p.created_at DESC
        ),
        '[]'::json
    )
    INTO threads
    FROM forum_posts p
    LEFT JOIN profiles pr ON p.user_id = pr.id
    LEFT JOIN forum_categories c ON p.category_id = c.id
    LEFT JOIN LATERAL (
        SELECT COUNT(*) as count
        FROM forum_comments
        WHERE post_id = p.id
    ) comment_counts ON true
    LEFT JOIN LATERAL (
        SELECT json_agg(t.name) as tags
        FROM post_tags pt
        JOIN forum_tags t ON pt.tag_id = t.id
        WHERE pt.post_id = p.id
    ) tag_array ON true
    WHERE (filter_category_id IS NULL OR p.category_id = filter_category_id)
    AND (search_term IS NULL OR 
         p.title ILIKE '%' || search_term || '%' OR 
         p.content ILIKE '%' || search_term || '%')
    LIMIT page_size
    OFFSET offset_value;

    -- Return the result
    RETURN json_build_object(
        'threads', threads,
        'total_pages', total_pages,
        'current_page', page_number,
        'page_size', page_size
    );
END;
$$;

-- Create get_comment_tree function
CREATE OR REPLACE FUNCTION get_comment_tree(p_post_id UUID)
RETURNS TABLE (
    id UUID,
    content TEXT,
    created_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ,
    user_id UUID,
    post_id UUID,
    parent_comment_id UUID,
    depth INTEGER,
    author JSON
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    WITH RECURSIVE comment_tree AS (
        -- Base case: get root comments
        SELECT 
            c.id,
            c.content,
            c.created_at,
            c.updated_at,
            c.user_id,
            c.post_id,
            c.parent_comment_id,
            0 as depth,
            json_build_object(
                'id', p.id,
                'username', p.username,
                'avatar_url', p.avatar_url
            ) as author
        FROM forum_comments c
        JOIN profiles p ON c.user_id = p.id
        WHERE c.post_id = p_post_id AND c.parent_comment_id IS NULL
        
        UNION ALL
        
        -- Recursive case: get child comments
        SELECT 
            c.id,
            c.content,
            c.created_at,
            c.updated_at,
            c.user_id,
            c.post_id,
            c.parent_comment_id,
            ct.depth + 1,
            json_build_object(
                'id', p.id,
                'username', p.username,
                'avatar_url', p.avatar_url
            ) as author
        FROM forum_comments c
        JOIN comment_tree ct ON c.parent_comment_id = ct.id
        JOIN profiles p ON c.user_id = p.id
    )
    SELECT * FROM comment_tree
    ORDER BY depth, created_at;
END;
$$;

-- Create handle_new_user function
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    INSERT INTO profiles (id, username, role)
    VALUES (
        NEW.id,
        COALESCE(NEW.raw_user_meta_data->>'username', 'user_' || substr(NEW.id::text, 1, 8)),
        'user'
    );
    RETURN NEW;
END;
$$;

-- Create get_user_role function
CREATE OR REPLACE FUNCTION get_user_role(user_id UUID)
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN (
        SELECT role
        FROM profiles
        WHERE id = user_id
    );
END;
$$;

-- Create trigger for new user
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW
    EXECUTE FUNCTION handle_new_user();

-- Grant execute permissions
GRANT EXECUTE ON FUNCTION is_username_available TO anon, authenticated;
GRANT EXECUTE ON FUNCTION get_thread_list TO anon, authenticated;
GRANT EXECUTE ON FUNCTION get_comment_tree TO anon, authenticated;
GRANT EXECUTE ON FUNCTION get_user_role TO anon, authenticated; 