-- Create forum categories table
CREATE TABLE forum_categories (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    icon TEXT,
    order_index INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- Create forum posts table
CREATE TABLE forum_posts (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    category_id UUID REFERENCES forum_categories(id) ON DELETE CASCADE,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    is_pinned BOOLEAN DEFAULT false,
    is_locked BOOLEAN DEFAULT false,
    view_count INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- Create forum comments table
CREATE TABLE forum_comments (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    post_id UUID REFERENCES forum_posts(id) ON DELETE CASCADE,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    parent_comment_id UUID REFERENCES forum_comments(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- Create forum reactions table
CREATE TABLE forum_reactions (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    post_id UUID REFERENCES forum_posts(id) ON DELETE CASCADE,
    comment_id UUID REFERENCES forum_comments(id) ON DELETE CASCADE,
    reaction_type TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    CONSTRAINT check_reaction_target CHECK (
        (post_id IS NOT NULL AND comment_id IS NULL) OR
        (post_id IS NULL AND comment_id IS NOT NULL)
    )
);

-- Create forum tags table
CREATE TABLE forum_tags (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    color TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- Create post_tags junction table
CREATE TABLE post_tags (
    post_id UUID REFERENCES forum_posts(id) ON DELETE CASCADE,
    tag_id UUID REFERENCES forum_tags(id) ON DELETE CASCADE,
    PRIMARY KEY (post_id, tag_id)
);

-- Create indexes for better performance
CREATE INDEX forum_posts_category_id_idx ON forum_posts(category_id);
CREATE INDEX forum_posts_user_id_idx ON forum_posts(user_id);
CREATE INDEX forum_comments_post_id_idx ON forum_comments(post_id);
CREATE INDEX forum_comments_user_id_idx ON forum_comments(user_id);
CREATE INDEX forum_reactions_post_id_idx ON forum_reactions(post_id);
CREATE INDEX forum_reactions_comment_id_idx ON forum_reactions(comment_id);
CREATE INDEX forum_reactions_user_id_idx ON forum_reactions(user_id);

-- Create updated_at triggers for all tables
CREATE TRIGGER update_forum_categories_updated_at
    BEFORE UPDATE ON forum_categories
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_forum_posts_updated_at
    BEFORE UPDATE ON forum_posts
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_forum_comments_updated_at
    BEFORE UPDATE ON forum_comments
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Enable Row Level Security
ALTER TABLE forum_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE forum_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE forum_comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE forum_reactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE forum_tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE post_tags ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for forum_categories
CREATE POLICY "Allow anonymous read access to categories"
    ON forum_categories FOR SELECT
    TO anon
    USING (true);

CREATE POLICY "Allow authenticated users to manage categories"
    ON forum_categories FOR ALL
    TO authenticated
    USING (true)
    WITH CHECK (true);

-- Create RLS policies for forum_posts
CREATE POLICY "Allow anonymous read access to posts"
    ON forum_posts FOR SELECT
    TO anon
    USING (true);

CREATE POLICY "Allow authenticated users to create posts"
    ON forum_posts FOR INSERT
    TO authenticated
    WITH CHECK (true);

CREATE POLICY "Allow users to update their own posts"
    ON forum_posts FOR UPDATE
    TO authenticated
    USING (auth.uid() = user_id)
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Allow users to delete their own posts"
    ON forum_posts FOR DELETE
    TO authenticated
    USING (auth.uid() = user_id);

-- Create RLS policies for forum_comments
CREATE POLICY "Allow anonymous read access to comments"
    ON forum_comments FOR SELECT
    TO anon
    USING (true);

CREATE POLICY "Allow authenticated users to create comments"
    ON forum_comments FOR INSERT
    TO authenticated
    WITH CHECK (true);

CREATE POLICY "Allow users to update their own comments"
    ON forum_comments FOR UPDATE
    TO authenticated
    USING (auth.uid() = user_id)
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Allow users to delete their own comments"
    ON forum_comments FOR DELETE
    TO authenticated
    USING (auth.uid() = user_id);

-- Create RLS policies for forum_reactions
CREATE POLICY "Allow anonymous read access to reactions"
    ON forum_reactions FOR SELECT
    TO anon
    USING (true);

CREATE POLICY "Allow authenticated users to manage reactions"
    ON forum_reactions FOR ALL
    TO authenticated
    USING (true)
    WITH CHECK (true);

-- Create RLS policies for forum_tags
CREATE POLICY "Allow anonymous read access to tags"
    ON forum_tags FOR SELECT
    TO anon
    USING (true);

CREATE POLICY "Allow authenticated users to manage tags"
    ON forum_tags FOR ALL
    TO authenticated
    USING (true)
    WITH CHECK (true);

-- Create RLS policies for post_tags
CREATE POLICY "Allow anonymous read access to post_tags"
    ON post_tags FOR SELECT
    TO anon
    USING (true);

CREATE POLICY "Allow authenticated users to manage post_tags"
    ON post_tags FOR ALL
    TO authenticated
    USING (true)
    WITH CHECK (true); 