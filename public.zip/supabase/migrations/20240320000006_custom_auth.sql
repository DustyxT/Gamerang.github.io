-- Drop existing auth-related functions and triggers
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS handle_new_user();
DROP FUNCTION IF EXISTS create_profile_for_user(uuid, text);
DROP FUNCTION IF EXISTS is_username_available(text);

-- Modify profiles table to remove auth dependency
ALTER TABLE profiles DROP CONSTRAINT IF EXISTS profiles_id_fkey;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS password_hash TEXT;

-- Create sessions table
CREATE TABLE IF NOT EXISTS sessions (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
    token TEXT NOT NULL UNIQUE,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- Create function to check username availability
CREATE OR REPLACE FUNCTION is_username_available(p_username TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    exists BOOLEAN;
BEGIN
    SELECT EXISTS (
        SELECT 1 FROM profiles WHERE username = p_username
    ) INTO exists;
    
    RETURN NOT exists;
END;
$$;

-- Create function to create a profile
CREATE OR REPLACE FUNCTION create_profile_for_user(
    p_user_id UUID,
    p_username TEXT
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    INSERT INTO profiles (id, username, role)
    VALUES (p_user_id, p_username, 'user');
END;
$$;

-- Grant necessary permissions
GRANT EXECUTE ON FUNCTION create_profile_for_user TO anon, authenticated;
GRANT EXECUTE ON FUNCTION is_username_available TO anon, authenticated;
GRANT ALL ON sessions TO anon, authenticated;
GRANT ALL ON profiles TO anon, authenticated;

-- Create RLS policies for sessions
ALTER TABLE sessions ENABLE ROW LEVEL SECURITY;

-- Allow all operations on sessions for now (we'll handle security in the application)
CREATE POLICY "Allow all operations on sessions"
    ON sessions FOR ALL
    USING (true)
    WITH CHECK (true);

-- Create RLS policies for profiles
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Allow all operations on profiles for now (we'll handle security in the application)
CREATE POLICY "Allow all operations on profiles"
    ON profiles FOR ALL
    USING (true)
    WITH CHECK (true); 