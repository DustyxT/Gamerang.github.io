-- First, drop the trigger
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

-- Now drop all forum-related tables and functions
DROP FUNCTION IF EXISTS public.get_thread_list(integer, integer, uuid, text);
DROP FUNCTION IF EXISTS public.get_comment_tree(uuid);
DROP FUNCTION IF EXISTS public.is_username_available(text);
DROP FUNCTION IF EXISTS public.handle_new_user();
DROP FUNCTION IF EXISTS public.get_user_role(uuid);

-- Drop tables in correct order (due to foreign key constraints)
DROP TABLE IF EXISTS post_tags;
DROP TABLE IF EXISTS forum_tags;
DROP TABLE IF EXISTS forum_comments;
DROP TABLE IF EXISTS forum_posts;
DROP TABLE IF EXISTS forum_categories;
DROP TABLE IF EXISTS profiles;

-- Now create tables in the correct order
-- 1. Profiles table
CREATE TABLE profiles (
    id UUID REFERENCES auth.users(id) PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    role TEXT NOT NULL DEFAULT 'user',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- 2. Forum Categories
CREATE TABLE forum_categories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    description TEXT,
    icon TEXT,
    order_index INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Forum Posts
CREATE TABLE forum_posts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    category_id UUID REFERENCES forum_categories(id) ON DELETE SET NULL,
    user_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    is_pinned BOOLEAN DEFAULT FALSE,
    is_locked BOOLEAN DEFAULT FALSE,
    view_count INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Forum Comments
CREATE TABLE forum_comments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    post_id UUID REFERENCES forum_posts(id) ON DELETE CASCADE,
    user_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
    parent_comment_id UUID REFERENCES forum_comments(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Forum Tags
CREATE TABLE forum_tags (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT UNIQUE NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. Post Tags (junction table)
CREATE TABLE post_tags (
    post_id UUID REFERENCES forum_posts(id) ON DELETE CASCADE,
    tag_id UUID REFERENCES forum_tags(id) ON DELETE CASCADE,
    PRIMARY KEY (post_id, tag_id)
);

-- Create necessary functions
-- 1. Username availability check
CREATE OR REPLACE FUNCTION is_username_available(username TEXT)
RETURNS BOOLEAN AS $$
BEGIN
    RETURN NOT EXISTS (
        SELECT 1 FROM profiles WHERE profiles.username = username
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 2. Auto-create profile on signup
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO profiles (id, username, role)
    VALUES (
        NEW.id,
        COALESCE(NEW.raw_user_meta_data->>'username', 'user_' || substr(NEW.id::text, 1, 8)),
        'user'
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 3. Get user role
CREATE OR REPLACE FUNCTION get_user_role(user_id UUID)
RETURNS TEXT AS $$
BEGIN
    RETURN (SELECT role FROM profiles WHERE id = user_id);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 4. Get thread list
CREATE OR REPLACE FUNCTION get_thread_list(
    page_size INTEGER DEFAULT 10,
    page_number INTEGER DEFAULT 1,
    filter_category_id UUID DEFAULT NULL,
    search_term TEXT DEFAULT NULL
)
RETURNS JSON AS $$
DECLARE
    total_threads INTEGER;
    threads JSON;
    total_pages INTEGER;
BEGIN
    -- Count total threads
    SELECT COUNT(*)
    INTO total_threads
    FROM forum_posts
    WHERE (filter_category_id IS NULL OR forum_posts.category_id = filter_category_id)
    AND (search_term IS NULL OR 
         forum_posts.title ILIKE '%' || search_term || '%' OR
         forum_posts.content ILIKE '%' || search_term || '%');

    -- Calculate total pages
    total_pages := CEIL(total_threads::FLOAT / page_size);

    -- Get threads with author info and comment count
    SELECT COALESCE(
        json_agg(
            json_build_object(
                'id', p.id,
                'title', p.title,
                'content', p.content,
                'created_at', p.created_at,
                'updated_at', p.updated_at,
                'author_id', p.user_id,
                'author_username', pr.username,
                'category_id', p.category_id,
                'comment_count', COALESCE(cc.count, 0),
                'is_pinned', p.is_pinned,
                'is_locked', p.is_locked
            )
        ),
        '[]'::json
    )
    INTO threads
    FROM forum_posts p
    LEFT JOIN profiles pr ON p.user_id = pr.id
    LEFT JOIN (
        SELECT post_id, COUNT(*) as count
        FROM forum_comments
        GROUP BY post_id
    ) cc ON p.id = cc.post_id
    WHERE (filter_category_id IS NULL OR p.category_id = filter_category_id)
    AND (search_term IS NULL OR 
         p.title ILIKE '%' || search_term || '%' OR
         p.content ILIKE '%' || search_term || '%')
    ORDER BY 
        p.is_pinned DESC,
        p.created_at DESC
    LIMIT page_size
    OFFSET (page_number - 1) * page_size;

    -- Return the result
    RETURN json_build_object(
        'threads', threads,
        'total_threads', total_threads,
        'total_pages', total_pages,
        'current_page', page_number,
        'page_size', page_size
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 5. Get comment tree
CREATE OR REPLACE FUNCTION get_comment_tree(post_id UUID)
RETURNS JSON AS $$
BEGIN
    RETURN (
        WITH RECURSIVE comment_tree AS (
            -- Base case: top-level comments
            SELECT 
                c.id,
                c.content,
                c.created_at,
                c.user_id,
                c.parent_comment_id,
                0 as depth,
                json_build_object(
                    'username', p.username,
                    'avatar_url', p.avatar_url
                ) as author
            FROM forum_comments c
            JOIN profiles p ON c.user_id = p.id
            WHERE c.post_id = post_id AND c.parent_comment_id IS NULL

            UNION ALL

            -- Recursive case: child comments
            SELECT 
                c.id,
                c.content,
                c.created_at,
                c.user_id,
                c.parent_comment_id,
                ct.depth + 1,
                json_build_object(
                    'username', p.username,
                    'avatar_url', p.avatar_url
                ) as author
            FROM forum_comments c
            JOIN profiles p ON c.user_id = p.id
            JOIN comment_tree ct ON c.parent_comment_id = ct.id
            WHERE c.post_id = post_id
        )
        SELECT json_agg(ct ORDER BY ct.created_at)
        FROM comment_tree ct
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create triggers
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- Set up Row Level Security (RLS)
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE forum_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE forum_comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE forum_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE forum_tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE post_tags ENABLE ROW LEVEL SECURITY;

-- Create policies
-- Profiles
CREATE POLICY "Public profiles are viewable by everyone"
    ON profiles FOR SELECT
    USING (true);

CREATE POLICY "Users can update their own profile"
    ON profiles FOR UPDATE
    USING (auth.uid() = id);

-- Forum Posts
CREATE POLICY "Anyone can view posts"
    ON forum_posts FOR SELECT
    USING (true);

CREATE POLICY "Authenticated users can create posts"
    ON forum_posts FOR INSERT
    WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Users can update their own posts"
    ON forum_posts FOR UPDATE
    USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own posts"
    ON forum_posts FOR DELETE
    USING (auth.uid() = user_id);

-- Forum Comments
CREATE POLICY "Anyone can view comments"
    ON forum_comments FOR SELECT
    USING (true);

CREATE POLICY "Authenticated users can create comments"
    ON forum_comments FOR INSERT
    WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Users can update their own comments"
    ON forum_comments FOR UPDATE
    USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own comments"
    ON forum_comments FOR DELETE
    USING (auth.uid() = user_id);

-- Forum Categories
CREATE POLICY "Anyone can view categories"
    ON forum_categories FOR SELECT
    USING (true);

-- Forum Tags
CREATE POLICY "Anyone can view tags"
    ON forum_tags FOR SELECT
    USING (true);

CREATE POLICY "Authenticated users can create tags"
    ON forum_tags FOR INSERT
    WITH CHECK (auth.role() = 'authenticated');

-- Post Tags
CREATE POLICY "Anyone can view post tags"
    ON post_tags FOR SELECT
    USING (true);

CREATE POLICY "Authenticated users can create post tags"
    ON post_tags FOR INSERT
    WITH CHECK (auth.role() = 'authenticated');

-- Grant permissions
GRANT EXECUTE ON FUNCTION public.get_thread_list(integer, integer, uuid, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_thread_list(integer, integer, uuid, text) TO anon;
GRANT EXECUTE ON FUNCTION public.get_comment_tree(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_comment_tree(uuid) TO anon;
GRANT EXECUTE ON FUNCTION public.is_username_available(text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_username_available(text) TO anon;
GRANT EXECUTE ON FUNCTION public.get_user_role(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_user_role(uuid) TO anon;

-- Insert some default categories
INSERT INTO forum_categories (name, description, order_index) VALUES
('General Discussion', 'General topics and discussions', 1),
('Game Reviews', 'Share your thoughts on games', 2),
('Technical Support', 'Get help with technical issues', 3),
('Community Events', 'Community events and announcements', 4); 