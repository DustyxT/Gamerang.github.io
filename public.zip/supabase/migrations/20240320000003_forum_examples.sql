-- Helper function to get post details with user info and comment count
CREATE OR REPLACE FUNCTION get_post_details(post_id UUID)
RETURNS JSON AS $$
BEGIN
    RETURN (
        SELECT json_build_object(
            'post', p.*,
            'author', json_build_object(
                'id', pr.id,
                'username', pr.username,
                'avatar_url', pr.avatar_url,
                'role', pr.role
            ),
            'comment_count', (
                SELECT COUNT(*)
                FROM forum_comments
                WHERE post_id = p.id
            ),
            'tags', (
                SELECT array_agg(t.name)
                FROM post_tags pt
                JOIN forum_tags t ON pt.tag_id = t.id
                WHERE pt.post_id = p.id
            )
        )
        FROM forum_posts p
        JOIN profiles pr ON p.user_id = pr.id
        WHERE p.id = post_id
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create function to get thread list with pagination
CREATE OR REPLACE FUNCTION get_thread_list(
    page_size INTEGER DEFAULT 10,
    page_number INTEGER DEFAULT 1,
    category_id UUID DEFAULT NULL,
    search_term TEXT DEFAULT NULL
)
RETURNS JSON AS $$
DECLARE
    total_threads INTEGER;
    threads JSON;
    total_pages INTEGER;
BEGIN
    -- Count total threads
    SELECT COUNT(*)
    INTO total_threads
    FROM forum_threads
    WHERE (category_id IS NULL OR forum_threads.category_id = category_id)
    AND (search_term IS NULL OR 
         forum_threads.title ILIKE '%' || search_term || '%' OR
         forum_threads.content ILIKE '%' || search_term || '%');

    -- Calculate total pages
    total_pages := CEIL(total_threads::FLOAT / page_size);

    -- Get threads with author info and comment count
    SELECT COALESCE(
        json_agg(
            json_build_object(
                'id', t.id,
                'title', t.title,
                'content', t.content,
                'created_at', t.created_at,
                'updated_at', t.updated_at,
                'author_id', t.author_id,
                'author_username', p.username,
                'category_id', t.category_id,
                'category_name', c.name,
                'comment_count', COALESCE(cc.count, 0),
                'is_pinned', t.is_pinned,
                'is_locked', t.is_locked,
                'tags', t.tags
            )
        ),
        '[]'::json
    )
    INTO threads
    FROM forum_threads t
    LEFT JOIN profiles p ON t.author_id = p.id
    LEFT JOIN forum_categories c ON t.category_id = c.id
    LEFT JOIN (
        SELECT thread_id, COUNT(*) as count
        FROM forum_comments
        GROUP BY thread_id
    ) cc ON t.id = cc.thread_id
    WHERE (category_id IS NULL OR t.category_id = category_id)
    AND (search_term IS NULL OR 
         t.title ILIKE '%' || search_term || '%' OR
         t.content ILIKE '%' || search_term || '%')
    ORDER BY 
        t.is_pinned DESC,
        t.created_at DESC
    LIMIT page_size
    OFFSET (page_number - 1) * page_size;

    -- Return the result
    RETURN json_build_object(
        'threads', threads,
        'total_threads', total_threads,
        'total_pages', total_pages,
        'current_page', page_number,
        'page_size', page_size
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Helper function to get comment tree for a post
CREATE OR REPLACE FUNCTION get_comment_tree(post_id UUID)
RETURNS JSON AS $$
BEGIN
    RETURN (
        WITH RECURSIVE comment_tree AS (
            -- Base case: top-level comments
            SELECT 
                c.*,
                pr.username,
                pr.avatar_url,
                pr.role,
                0 as depth,
                ARRAY[c.id] as path
            FROM forum_comments c
            JOIN profiles pr ON c.user_id = pr.id
            WHERE c.post_id = post_id AND c.parent_comment_id IS NULL

            UNION ALL

            -- Recursive case: child comments
            SELECT 
                c.*,
                pr.username,
                pr.avatar_url,
                pr.role,
                ct.depth + 1,
                ct.path || c.id
            FROM forum_comments c
            JOIN profiles pr ON c.user_id = pr.id
            JOIN comment_tree ct ON c.parent_comment_id = ct.id
            WHERE c.post_id = post_id
        )
        SELECT json_agg(
            json_build_object(
                'id', id,
                'content', content,
                'created_at', created_at,
                'updated_at', updated_at,
                'author', json_build_object(
                    'id', user_id,
                    'username', username,
                    'avatar_url', avatar_url,
                    'role', role
                ),
                'depth', depth,
                'path', path
            )
            ORDER BY path
        )
        FROM comment_tree
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Example usage in JavaScript:

/*
// Get thread list with pagination
const { data, error } = await supabase
    .rpc('get_thread_list', {
        page_size: 10,
        page_number: 1,
        category_id: 'optional-category-uuid',
        search_term: 'optional-search-term'
    });

// Get single post details
const { data, error } = await supabase
    .rpc('get_post_details', {
        post_id: 'post-uuid'
    });

// Get comment tree for a post
const { data, error } = await supabase
    .rpc('get_comment_tree', {
        post_id: 'post-uuid'
    });
*/

-- Example of creating a new post
/*
const { data, error } = await supabase
    .from('forum_posts')
    .insert({
        category_id: 'category-uuid',
        title: 'Post Title',
        content: 'Post content...',
        user_id: 'current-user-uuid'
    })
    .select()
    .single();
*/

-- Example of adding a comment
/*
const { data, error } = await supabase
    .from('forum_comments')
    .insert({
        post_id: 'post-uuid',
        parent_comment_id: 'optional-parent-comment-uuid',
        content: 'Comment content...',
        user_id: 'current-user-uuid'
    })
    .select()
    .single();
*/

-- Example of adding tags to a post
/*
const { data, error } = await supabase
    .from('post_tags')
    .insert([
        { post_id: 'post-uuid', tag_id: 'tag1-uuid' },
        { post_id: 'post-uuid', tag_id: 'tag2-uuid' }
    ]);
*/ 