-- Add unique constraint on username
alter table profiles add constraint profiles_username_key unique (username);

-- Drop existing function if it exists
drop function if exists handle_signup;

-- Create a function to handle the entire signup process
create or replace function handle_signup(
    p_user_id uuid,
    p_username text,
    p_password_hash text,
    p_role text default 'user'
) returns json as $$
declare
    v_profile json;
    v_attempt integer := 0;
    v_current_username text;
    v_success boolean := false;
begin
    -- First check if a profile with this user_id already exists
    if exists (select 1 from profiles where id = p_user_id) then
        return json_build_object(
            'success', false,
            'error', 'User already exists'
        );
    end if;

    -- Start with the requested username
    v_current_username := p_username;
    
    -- Try up to 3 times with different usernames
    while v_attempt < 3 and not v_success loop
        -- Check if username exists
        if not exists (select 1 from profiles where username = v_current_username) then
            -- Create the profile
            insert into profiles (id, username, password_hash, role)
            values (p_user_id, v_current_username, p_password_hash, p_role)
            returning json_build_object(
                'id', id,
                'username', username,
                'role', role
            ) into v_profile;
            
            v_success := true;
        else
            -- Try next username
            v_attempt := v_attempt + 1;
            v_current_username := p_username || v_attempt::text;
        end if;
    end loop;

    if v_success then
        return json_build_object(
            'success', true,
            'profile', v_profile,
            'attempts', v_attempt
        );
    else
        return json_build_object(
            'success', false,
            'error', 'Failed to create profile after multiple attempts'
        );
    end if;
exception
    when others then
        -- Rollback any changes
        return json_build_object(
            'success', false,
            'error', SQLERRM
        );
end;
$$ language plpgsql security definer;

-- Grant execute permission to authenticated users
grant execute on function handle_signup to authenticated;

-- Add a trigger to prevent duplicate user_ids
create or replace function prevent_duplicate_profiles()
returns trigger as $$
begin
    if exists (select 1 from profiles where id = NEW.id) then
        raise exception 'Profile with this ID already exists';
    end if;
    return NEW;
end;
$$ language plpgsql;

drop trigger if exists prevent_duplicate_profiles_trigger on profiles;
create trigger prevent_duplicate_profiles_trigger
    before insert on profiles
    for each row
    execute function prevent_duplicate_profiles(); 