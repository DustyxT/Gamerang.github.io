// Forum functionality
class Forum {
    constructor() {
        // Use the global supabase client
        this.supabase = window.supabase;
        if (!this.supabase) {
            console.error('Supabase client not initialized');
            return;
        }
        this.currentPage = 1;
        this.pageSize = 10;
        this.selectedCategory = null;
        this.searchTerm = '';
        this.threadsContainer = document.querySelector('.threads-container');
        
        if (!this.threadsContainer) {
            console.error('Threads container not found');
            return;
        }
        this.setupEventListeners();
        this.loadCategories();
        this.loadThreads();
    }

    setupEventListeners() {
        // Category filter
        const categorySelect = document.getElementById('categorySelect');
        if (categorySelect) {
            categorySelect.addEventListener('change', (e) => {
                this.selectedCategory = e.target.value || null;
                this.currentPage = 1;
                this.loadThreads();
            });
        }

        // Search input
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.searchTerm = e.target.value.trim();
                this.currentPage = 1;
                this.loadThreads();
            });
        }

        // Pagination
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('page-link')) {
                e.preventDefault();
                const page = parseInt(e.target.dataset.page);
                if (page && page !== this.currentPage) {
                    this.currentPage = page;
                    this.loadThreads();
                }
            }
        });

        // New thread form
        const newThreadForm = document.getElementById('newThreadForm');
        if (newThreadForm) {
            newThreadForm.addEventListener('submit', this.handleNewThread.bind(this));
        }

        // Comment form
        const commentForm = document.getElementById('commentForm');
        if (commentForm) {
            commentForm.addEventListener('submit', this.handleNewComment.bind(this));
        }
    }

    async loadCategories() {
        try {
            if (!this.supabase) {
                console.error('Supabase client not initialized');
                return;
            }

            const { data: categories, error } = await this.supabase
                .from('forum_categories')
                .select('*')
                .order('order_index');

            if (error) throw error;

            const categorySelect = document.getElementById('categorySelect');
            if (categorySelect) {
                categorySelect.innerHTML = `
                    <option value="">All Categories</option>
                    ${categories.map(category => `
                        <option value="${category.id}">${category.name}</option>
                    `).join('')}
                `;
            }

            // Also update the new thread form's category select
            const newThreadCategorySelect = document.querySelector('#newThreadForm select[name="category"]');
            if (newThreadCategorySelect) {
                newThreadCategorySelect.innerHTML = `
                    <option value="">Select a category</option>
                    ${categories.map(category => `
                        <option value="${category.id}">${category.name}</option>
                    `).join('')}
                `;
            }
        } catch (error) {
            console.error('Error loading categories:', error);
            this.showError('Failed to load categories. Please try again.');
        }
    }

    async loadThreads() {
        try {
            if (!this.supabase) {
                console.error('Supabase client not initialized');
                return;
            }

            if (!this.threadsContainer) {
                console.error('Threads container not found');
                return;
            }

            const { data, error } = await this.supabase.rpc('get_thread_list', {
                page_size: this.pageSize,
                page_number: this.currentPage,
                filter_category_id: this.selectedCategory,
                search_term: this.searchTerm
            });

            if (error) {
                console.error('Threads error:', error);
                throw error;
            }

            if (!data) {
                throw new Error('No data returned from get_thread_list');
            }

            this.threads = data.threads || [];
            this.totalPages = data.total_pages || 1;
            this.renderThreads();
            this.renderPagination();
        } catch (error) {
            console.error('Error loading threads:', error);
            this.threadsContainer.innerHTML = `
                <div class="text-center py-8">
                    <p class="text-red-500 mb-4">Failed to load threads. Please try again.</p>
                    <p class="text-sm text-gray-500">Error: ${error.message}</p>
                </div>
            `;
        }
    }

    renderThreads() {
        if (!this.threadsContainer) return;

        if (!this.threads || this.threads.length === 0) {
            this.threadsContainer.innerHTML = `
                <div class="text-center py-8">
                    <p class="text-gray-400 mb-4">No threads found.</p>
                    <button onclick="document.getElementById('newThreadModal').classList.remove('hidden')"
                            class="bg-gradient-to-r from-neon-blue to-neon-purple text-white px-4 py-2 rounded-lg hover:opacity-90 transition-all duration-300">
                        Create New Thread
                    </button>
                </div>
            `;
            return;
        }

        this.threadsContainer.innerHTML = this.threads.map(thread => `
            <div class="forum-post bg-gray-800/50 rounded-lg p-4 mb-4 neon-card" data-thread-id="${thread.id}">
                <div class="flex items-start justify-between">
                    <div class="flex-1">
                        <h3 class="text-xl font-semibold mb-2">
                            <a href="#" class="hover:text-neon-blue transition">${thread.title}</a>
                        </h3>
                        <div class="flex items-center space-x-4 text-sm text-gray-400">
                            <span>Posted by ${thread.author_username}</span>
                            <span>${new Date(thread.created_at).toLocaleDateString()}</span>
                            <span>${thread.comment_count} comments</span>
                        </div>
                    </div>
                    <div class="flex items-center space-x-2">
                        ${thread.is_pinned ? '<span class="text-neon-blue"><i class="fas fa-thumbtack"></i></span>' : ''}
                        ${thread.is_locked ? '<span class="text-red-500"><i class="fas fa-lock"></i></span>' : ''}
                    </div>
                </div>
            </div>
        `).join('');
    }

    renderPagination() {
        const container = document.getElementById('pagination');
        if (!container) return;

        if (this.totalPages <= 1) {
            container.innerHTML = '';
            return;
        }

        let paginationHTML = '<div class="flex justify-center space-x-2">';

        // Previous button
        paginationHTML += `
            <a href="#" class="page-link px-3 py-1 rounded ${this.currentPage === 1 ? 'bg-gray-700 cursor-not-allowed' : 'bg-gray-800 hover:bg-gray-700'}"
               data-page="${this.currentPage - 1}" ${this.currentPage === 1 ? 'disabled' : ''}>
                Previous
            </a>
        `;

        // Page numbers
        for (let i = 1; i <= this.totalPages; i++) {
            if (
                i === 1 || 
                i === this.totalPages || 
                (i >= this.currentPage - 2 && i <= this.currentPage + 2)
            ) {
                paginationHTML += `
                    <a href="#" class="page-link px-3 py-1 rounded ${i === this.currentPage ? 'bg-neon-blue text-white' : 'bg-gray-800 hover:bg-gray-700'}"
                       data-page="${i}">
                        ${i}
                    </a>
                `;
            } else if (
                i === this.currentPage - 3 || 
                i === this.currentPage + 3
            ) {
                paginationHTML += '<span class="px-2">...</span>';
            }
        }

        // Next button
        paginationHTML += `
            <a href="#" class="page-link px-3 py-1 rounded ${this.currentPage === this.totalPages ? 'bg-gray-700 cursor-not-allowed' : 'bg-gray-800 hover:bg-gray-700'}"
               data-page="${this.currentPage + 1}" ${this.currentPage === this.totalPages ? 'disabled' : ''}>
                Next
            </a>
        `;

        paginationHTML += '</div>';
        container.innerHTML = paginationHTML;
    }

    async handleNewThread(e) {
        e.preventDefault();
        
        try {
            const { data: { user } } = await this.supabase.auth.getUser();
            if (!user) {
                this.showError('Please sign in to create a thread');
                return;
            }

            const formData = new FormData(e.target);
            const title = formData.get('title').trim();
            const content = formData.get('content').trim();
            const categoryId = formData.get('category');
            const tags = formData.get('tags')
                .split(',')
                .map(tag => tag.trim())
                .filter(tag => tag);

            if (!title || !content || !categoryId) {
                this.showError('Please fill in all required fields');
                return;
            }

            // Create the post
            const { data: post, error: postError } = await this.supabase
                .from('forum_posts')
                .insert({
                    title,
                    content,
                    category_id: categoryId,
                    user_id: user.id
                })
                .select()
                .single();

            if (postError) throw postError;

            // Add tags if any
            if (tags.length > 0) {
                // First, get or create tags
                const tagPromises = tags.map(async (tagName) => {
                    const { data: existingTag } = await this.supabase
                        .from('forum_tags')
                        .select('id')
                        .eq('name', tagName)
                        .single();

                    if (existingTag) return existingTag.id;

                    const { data: newTag } = await this.supabase
                        .from('forum_tags')
                        .insert({ name: tagName })
                        .select()
                        .single();

                    return newTag.id;
                });

                const tagIds = await Promise.all(tagPromises);

                // Then, link tags to post
                await this.supabase
                    .from('post_tags')
                    .insert(
                        tagIds.map(tagId => ({
                            post_id: post.id,
                            tag_id: tagId
                        }))
                    );
            }

            this.showSuccess('Thread created successfully!');
            e.target.reset();
            this.loadThreads();
        } catch (error) {
            console.error('Error creating thread:', error);
            this.showError('Failed to create thread. Please try again.');
        }
    }

    async handleNewComment(e) {
        e.preventDefault();
        
        try {
            const { data: { user } } = await this.supabase.auth.getUser();
            if (!user) {
                this.showError('Please sign in to comment');
                return;
            }

            const formData = new FormData(e.target);
            const content = formData.get('content').trim();
            const postId = formData.get('postId');
            const parentCommentId = formData.get('parentCommentId') || null;

            if (!content || !postId) {
                this.showError('Please enter a comment');
                return;
            }

            const { error } = await this.supabase
                .from('forum_comments')
                .insert({
                    content,
                    post_id: postId,
                    parent_comment_id: parentCommentId,
                    user_id: user.id
                });

            if (error) throw error;

            this.showSuccess('Comment added successfully!');
            e.target.reset();
            this.loadComments(postId);
        } catch (error) {
            console.error('Error adding comment:', error);
            this.showError('Failed to add comment. Please try again.');
        }
    }

    async loadComments(postId) {
        try {
            const { data, error } = await this.supabase.rpc('get_comment_tree', {
                post_id: postId
            });

            if (error) throw error;

            this.renderComments(data);
        } catch (error) {
            console.error('Error loading comments:', error);
            this.showError('Failed to load comments. Please try again.');
        }
    }

    renderComments(comments) {
        const container = document.querySelector('.comments-container');
        if (!container) return;

        if (!comments || comments.length === 0) {
            container.innerHTML = '<div class="text-center py-4 text-gray-400">No comments yet.</div>';
            return;
        }

        container.innerHTML = comments.map(comment => `
            <div class="comment bg-gray-800/50 rounded-lg p-4 mb-4" 
                 style="margin-left: ${comment.depth * 2}rem">
                <div class="flex items-start">
                    <img src="${comment.author.avatar_url || 'https://via.placeholder.com/32'}" 
                         alt="${comment.author.username}" 
                         class="w-8 h-8 rounded-full mr-3">
                    <div class="flex-1">
                        <div class="flex items-center mb-2">
                            <span class="font-semibold mr-2">${comment.author.username}</span>
                            <span class="text-sm text-gray-400">
                                ${new Date(comment.created_at).toLocaleDateString()}
                            </span>
                        </div>
                        <div class="text-gray-300 mb-2">${comment.content}</div>
                        <div class="flex items-center space-x-4 text-sm">
                            <button class="reply-btn text-neon-blue hover:text-neon-purple transition"
                                    data-comment-id="${comment.id}">
                                <i class="far fa-reply mr-1"></i> Reply
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `).join('');

        // Add reply button event listeners
        container.querySelectorAll('.reply-btn').forEach(button => {
            button.addEventListener('click', () => {
                const commentId = button.dataset.commentId;
                const replyForm = document.getElementById('replyForm');
                if (replyForm) {
                    replyForm.querySelector('input[name="parentCommentId"]').value = commentId;
                    replyForm.scrollIntoView({ behavior: 'smooth' });
                }
            });
        });
    }

    showError(message) {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'fixed top-4 right-4 bg-red-500 text-white px-6 py-3 rounded-lg shadow-lg z-50';
        errorDiv.textContent = message;
        document.body.appendChild(errorDiv);
        setTimeout(() => errorDiv.remove(), 5000);
    }

    showSuccess(message) {
        const successDiv = document.createElement('div');
        successDiv.className = 'fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50';
        successDiv.textContent = message;
        document.body.appendChild(successDiv);
        setTimeout(() => successDiv.remove(), 5000);
    }

    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
}

// Initialize forum when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.forum = new Forum();
}); 