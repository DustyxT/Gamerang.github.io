// Authentication functionality
class Auth {
    constructor() {
        console.log('Auth class constructor called'); // Log constructor calls

        // Use the global supabase client
        this.supabase = window.supabase;
        if (!this.supabase) {
            console.error('Supabase client not initialized');
            return;
        }
        this.isSigningUp = false; // Add a flag to prevent duplicate submissions
        this.setupEventListeners();
        this.checkSession();

        this.supabase.auth.onAuthStateChange((event, session) => {
            if (session) {
                // User is signed in
                // You can fetch the user's profile here if needed
            } else {
                // User is signed out
            }
        });
    }

    setupEventListeners() {
        // Sign up form
        const signUpForm = document.getElementById('signUpForm');
        if (signUpForm) {
            signUpForm.addEventListener('submit', this.handleSignUp.bind(this));
        }

        // Sign in form
        const signInForm = document.getElementById('signInForm');
        if (signInForm) {
            signInForm.addEventListener('submit', this.handleSignIn.bind(this));
        }

        // Sign out button
        const signOutBtn = document.getElementById('signOutBtn');
        if (signOutBtn) {
            signOutBtn.addEventListener('click', this.handleSignOut.bind(this));
        }
    }

    async checkSession() {
        try {
            const { data: { user } } = await this.supabase.auth.getUser();
            if (user) {
                // User is signed in
                // user.user_metadata.username is available
                this.updateUI(true, user.user_metadata.username, user.user_metadata.role === 'admin');
            } else {
                // User is not signed in
                this.updateUI(false);
            }
        } catch (error) {
            console.error('Error checking session:', error);
            this.updateUI(false);
        }
    }

    async handleSignUp(e) {
        e.preventDefault();

        if (this.isSigningUp) return;
        this.isSigningUp = true;

        const submitButton = e.target.querySelector('button[type="submit"]');
        if (submitButton) {
            submitButton.disabled = true;
            submitButton.textContent = 'Signing Up...';
        }

        try {
            const formData = new FormData(e.target);
            const email = formData.get('email').trim();
            const username = formData.get('username').trim();
            const password = formData.get('password').trim();

            if (!email || !username || !password) {
                this.showError('Please fill in all fields');
                return;
            }
            if (username.length < 3) {
                this.showError('Username must be at least 3 characters long');
                return;
            }
            if (password.length < 6) {
                this.showError('Password must be at least 6 characters long');
                return;
            }

            // Use Supabase Auth for sign up (if you want to use password auth)
            const { data, error } = await this.supabase.auth.signUp({
                email,
                password,
                options: {
                    data: { username }
                }
            });

            if (error) {
                this.showError(error.message || 'Failed to sign up. Please try again.');
                return;
            }

            this.showSuccess('Account created!');
            document.getElementById('signUpModal').classList.add('hidden');
            e.target.reset();
            document.getElementById('error-message').style.display = 'none';
        } catch (error) {
            this.showError(error.message || 'Failed to sign up. Please try again.');
        } finally {
            if (submitButton) {
                submitButton.disabled = false;
                submitButton.textContent = 'Sign Up';
            }
            this.isSigningUp = false;
        }
    }

    async handleSignIn(e) {
        e.preventDefault();
        
        try {
            const formData = new FormData(e.target);
            const username = formData.get('username').trim();
            const password = formData.get('password');

            if (!username || !password) {
                this.showError('Please fill in all fields');
                return;
            }

            if (password.length < 6) {
                this.showError('Password must be at least 6 characters long');
                return;
            }

            console.log('Attempting to sign in with username:', username);

            const { data, error } = await this.supabase
                .from('profiles')
                .select('*')
                .eq('username', username)
                .single();

            if (error || !data) {
                this.showError('Invalid username or password');
                return;
            }

            // You should hash the password and compare with data.password_hash here
            // (Add your password hash check logic)

            this.showSuccess('Signed in successfully!');
            document.getElementById('signInModal').classList.add('hidden');
            e.target.reset();
            this.updateUI(true, data.username, data.role === 'admin');
        } catch (error) {
            console.error('Error signing in:', error);
            this.showError(error.message || 'Failed to sign in. Please try again.');
        }
    }

    async handleSignOut() {
        try {
            await this.supabase.auth.signOut();
            
            localStorage.removeItem('session_token');
            localStorage.removeItem('user_id');
            
            this.showSuccess('Signed out successfully!');
            this.updateUI(false);
        } catch (error) {
            console.error('Error signing out:', error);
            this.showError('Failed to sign out. Please try again.');
        }
    }

    async hashPassword(password) {
        const encoder = new TextEncoder();
        const data = encoder.encode(password);
        const hash = await crypto.subtle.digest('SHA-256', data);
        return Array.from(new Uint8Array(hash))
            .map(b => b.toString(16).padStart(2, '0'))
            .join('');
    }

    updateUI(isAuthenticated, username = null, isAdmin = false) {
        const authButtons = document.getElementById('authButtons');
        const userInfo = document.getElementById('userInfo');
        const newThreadBtn = document.getElementById('newThreadBtn');
        const adminPanel = document.getElementById('adminPanel');

        if (isAuthenticated) {
            authButtons.classList.add('hidden');
            userInfo.classList.remove('hidden');
            if (newThreadBtn) newThreadBtn.classList.remove('hidden');
            
            const usernameSpan = document.getElementById('username');
            if (usernameSpan) usernameSpan.textContent = username;

            // Show/hide admin panel based on role
            if (adminPanel) {
                if (isAdmin) {
                    adminPanel.classList.remove('hidden');
                } else {
                    adminPanel.classList.add('hidden');
                }
            }
        } else {
            authButtons.classList.remove('hidden');
            userInfo.classList.add('hidden');
            if (newThreadBtn) newThreadBtn.classList.add('hidden');
            if (adminPanel) adminPanel.classList.add('hidden');
        }
    }

    showError(message) {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'fixed top-4 right-4 bg-red-500 text-white px-6 py-3 rounded-lg shadow-lg z-50';
        errorDiv.textContent = message;
        document.body.appendChild(errorDiv);
        setTimeout(() => errorDiv.remove(), 5000);
    }

    showSuccess(message) {
        const successDiv = document.createElement('div');
        successDiv.className = 'fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50';
        successDiv.textContent = message;
        document.body.appendChild(successDiv);
        setTimeout(() => successDiv.remove(), 5000);
    }
}

// Initialize auth when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Prevent multiple initializations
    if (!window.authInitialized) {
        window.auth = new Auth();
        window.authInitialized = true;
    }
}); 